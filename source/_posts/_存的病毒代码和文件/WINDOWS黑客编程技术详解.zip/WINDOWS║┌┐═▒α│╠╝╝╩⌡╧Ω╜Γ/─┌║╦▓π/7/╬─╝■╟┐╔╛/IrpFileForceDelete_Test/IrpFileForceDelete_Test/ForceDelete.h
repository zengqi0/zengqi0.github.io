#ifndef _FORCE_DELETE_H_
#define _FORCE_DELETE_H_


#include "IrpFile.h"


// ǿ��ɾ���ļ�
NTSTATUS ForceDeleteFile(UNICODE_STRING ustrFileName);


#endif