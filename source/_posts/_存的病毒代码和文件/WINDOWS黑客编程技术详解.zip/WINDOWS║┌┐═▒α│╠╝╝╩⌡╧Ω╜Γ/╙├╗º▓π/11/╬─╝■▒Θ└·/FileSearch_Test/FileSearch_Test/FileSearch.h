#ifndef _FILE_SEARCH_H_
#define _FILE_SEARCH_H_


#include <Windows.h>

void SearchFile(char *pszDirectory);

#endif