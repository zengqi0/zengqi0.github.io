#ifndef _SCREEN_CAPTURE_H_
#define _SCREEN_CAPTURE_H_


#include "BmpSave_CImage.h"


BOOL ScreenCapture();


#endif