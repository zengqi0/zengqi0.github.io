﻿========================================================================
    动态链接库：HideProcess_ZwQuerySystemInformation_Test 项目概述
========================================================================

应用程序向导已为您创建了此 HideProcess_ZwQuerySystemInformation_Test DLL。

本文件概要介绍组成 HideProcess_ZwQuerySystemInformation_Test 应用程序的每个文件的内容。


HideProcess_ZwQuerySystemInformation_Test.vcxproj
    这是使用应用程序向导生成的 VC++ 项目的主项目文件，其中包含生成该文件的 Visual C++ 的版本信息，以及有关使用应用程序向导选择的平台、配置和项目功能的信息。

HideProcess_ZwQuerySystemInformation_Test.vcxproj.filters
    这是使用“应用程序向导”生成的 VC++ 项目筛选器文件。它包含有关项目文件与筛选器之间的关联信息。在 IDE 中，通过这种关联，在特定节点下以分组形式显示具有相似扩展名的文件。例如，“.cpp”文件与“源文件”筛选器关联。

HideProcess_ZwQuerySystemInformation_Test.cpp
    这是主 DLL 源文件。

	此 DLL 在创建时不导出任何符号。因此，生成时不会产生 .lib 文件。如果希望此项目成为其他某个项目的项目依赖项，则需要添加代码以从 DLL 导出某些符号，以便产生一个导出库，或者，也可以在项目“属性页”对话框中的“链接器”文件夹中，将“常规”属性页上的“忽略输入库”属性设置为“是”。

/////////////////////////////////////////////////////////////////////////////
其他标准文件:

StdAfx.h, StdAfx.cpp
    这些文件用于生成名为 HideProcess_ZwQuerySystemInformation_Test.pch 的预编译头 (PCH) 文件和名为 StdAfx.obj 的预编译类型文件。

/////////////////////////////////////////////////////////////////////////////
其他注释:

应用程序向导使用“TODO:”注释来指示应添加或自定义的源代码部分。

/////////////////////////////////////////////////////////////////////////////
